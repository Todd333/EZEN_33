from cont.contact import Contacts

if __name__ == '__main__':
    Contacts.run()
    # c=Contacts()   staticmethod 을 사용할 경우 사용